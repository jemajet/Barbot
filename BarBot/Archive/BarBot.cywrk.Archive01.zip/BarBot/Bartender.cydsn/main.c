/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include "GUI.h"

#define MOTOR_COUNT 6
#define PUMP_RATE 400 // mL / min
int clean_button_number(int button_num);
void relay_flip(int button_num);
int button_number = 0;
int SCREEN_X; // 240
int SCREEN_Y; // 320
char print[100];

CY_ISR ( Down_Button_Handler ) {
    button_number--;
    button_number = clean_button_number(button_number);
}
CY_ISR ( Up_Button_Handler ) {
    button_number++;
    button_number = clean_button_number(button_number);
}

CY_ISR ( Submit_Button_Handler ) {
    relay_flip(button_number);
    //Relay_1_Write(~Relay_1_Read());
    //Submit_ClearInterrupt();
}

void MainTask(void);

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Submit_Int_StartEx( Submit_Button_Handler );
    Up_Int_StartEx( Up_Button_Handler );
    Down_Int_StartEx( Down_Button_Handler );
    SPIM_1_Start();
    MainTask();
    for(;;)
    {
        /* Place your application code here. */
    }
}
void MainTask()
{
    GUI_Init();                             // initilize graphics library
    GUI_Clear();
    SCREEN_X = GUI_GetScreenSizeX();
    SCREEN_Y = GUI_GetScreenSizeY();
    sprintf(print, "Screen Size (x, y): (%d, %d)", SCREEN_X, SCREEN_Y);
    GUI_SetFont(&GUI_Font8x16);
    GUI_DispStringAt(print, 0, 50);
}

int clean_button_number(int button_num) {
    return (button_num + MOTOR_COUNT) % MOTOR_COUNT;
}

void relay_flip(int button_num) {
    if (button_num == 0) {
        Relay_1_Write(~Relay_1_Read());
    } else if (button_num == 1) {
        Relay_2_Write(~Relay_2_Read());
    } else if (button_num == 2) {
        Relay_3_Write(~Relay_3_Read());
    } else if (button_num == 3) {
        Relay_4_Write(~Relay_4_Read());
    } else if (button_num == 4) {
        Relay_5_Write(~Relay_5_Read());
    } else if (button_num == 5) {
        Relay_6_Write(~Relay_6_Read());
    }
}
/* [] END OF FILE */
